import calendar

Year = int(input('Enter a year:'))
month = int(input('Enter Month:'))
print(calendar.month(Year,month))